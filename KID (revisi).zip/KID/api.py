from fastapi import FastAPI, UploadFile, File, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, APIKeyHeader
from datetime import datetime, timedelta
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import base64
import json
import jwt
import os


# =========================
# SECURITY SCHEME
# =========================
oauth2_scheme = APIKeyHeader(name="Authorization")
bearer_scheme = HTTPBearer()

# =========================
# SERVER PRIVATE KEY (ED25519)
# =========================
SERVER_PRIVKEY_PATH = "punkhazard-keys/priv19.pem"
if os.path.exists(SERVER_PRIVKEY_PATH):
    with open(SERVER_PRIVKEY_PATH, "rb") as f:
        SERVER_PRIVATE_KEY = serialization.load_pem_private_key(f.read(), password=None)
else:
    SERVER_PRIVATE_KEY = None


# =========================
# JWT CONFIG (HS256)
# =========================
JWT_SECRET = "SUPER_SECRET_CHANGE_THIS"
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_MINUTES = 60


def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=JWT_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
    token = credentials.credentials
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return data["sub"]
    except:
        raise HTTPException(status_code=401, detail="Token invalid / expired")


# =========================
# AES SYMMETRIC CRYPTO (BARU)
# =========================
AES_KEY = os.urandom(32)  

def encrypt_data(data: bytes):
    aes = AESGCM(AES_KEY)
    nonce = os.urandom(12)
    ciphertext = aes.encrypt(nonce, data, None)
    return nonce, ciphertext

def decrypt_data(nonce: bytes, ciphertext: bytes):
    aes = AESGCM(AES_KEY)
    return aes.decrypt(nonce, ciphertext, None)


# =========================
# FASTAPI INIT
# =========================
app = FastAPI(
    title="Security Service",
    version="1.0.0",
    description="UAS KID"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# STORAGE
# =========================
DATA_DIR = "data"
KEY_FILE = f"{DATA_DIR}/keys.json"
VERIFY_LOG = f"{DATA_DIR}/verify_log.json"
RELAY_LOG = f"{DATA_DIR}/relay_log.json"

os.makedirs(DATA_DIR, exist_ok=True)

for file in [KEY_FILE, VERIFY_LOG, RELAY_LOG]:
    if not os.path.exists(file):
        with open(file, "w") as f:
            f.write("[]" if "log" in file else "{}")

# =========================
# HEALTH CHECK
# =========================
@app.get("/health")
async def health_check():
    return {
        "status": "UP",
        "server_time": datetime.now().isoformat(),
        "storage": {
            "keys_file": os.path.exists(KEY_FILE),
            "verify_log": os.path.exists(VERIFY_LOG),
            "relay_log": os.path.exists(RELAY_LOG)
        },
        "crypto": {
            "aes_256_ready": AES_KEY is not None,
            "server_private_key_loaded": SERVER_PRIVATE_KEY is not None
        },
        "auth": {
            "jwt_enabled": True
        }
    }
# =========================
# ROOT
# =========================
@app.get("/")
async def index():
    return {
        "message": "Server SecurityAPI aktif! Buka /docs untuk testing API.",
        "timestamp": datetime.now().isoformat()
    }


# =========================
# STORE PUBLIC KEY
# =========================
@app.post("/store")
async def store_pubkey(username: str, key: UploadFile = File(...)):
    if not key.filename.endswith(".pem"):
        raise HTTPException(400, "File harus .pem")

    key_data = (await key.read()).decode("utf-8")

    with open(KEY_FILE, "r") as f:
        data = json.load(f)

    data[username] = key_data

    with open(KEY_FILE, "w") as f:
        json.dump(data, f, indent=4)

    return {"message": "Public key disimpan", "username": username}


# =========================
# VERIFY MESSAGE SIGNATURE
# =========================
@app.post("/verify")
async def verify_signature(username: str, message: str, signature: str):
    with open(KEY_FILE, "r") as f:
        data = json.load(f)

    if username not in data:
        return {"verified": False}

    public_key = serialization.load_pem_public_key(data[username].encode())

    # ENCRYPT MESSAGE (SIMETRIK)
    nonce, encrypted_message = encrypt_data(message.encode())

    verified = True
    try:
        public_key.verify(base64.b64decode(signature), encrypted_message)
    except:
        verified = False

    with open(VERIFY_LOG, "r") as f:
        logs = json.load(f)

    logs.append({
        "username": username,
        "verified": verified,
        "timestamp": datetime.now().isoformat()
    })

    with open(VERIFY_LOG, "w") as f:
        json.dump(logs, f, indent=4)

    return {"verified": verified}


# =========================
# RELAY MESSAGE (SIMETRIK + ASIMETRIK)
# =========================
@app.post("/relay")
async def relay_message(sender: str, receiver: str, message: str, signature: str):
    with open(KEY_FILE, "r") as f:
        data = json.load(f)

    if sender not in data:
        return {"relayed": False}

    public_key = serialization.load_pem_public_key(data[sender].encode())

    nonce, encrypted_message = encrypt_data(message.encode())

    verified = True
    try:
        public_key.verify(base64.b64decode(signature), encrypted_message)
    except:
        verified = False

    with open(RELAY_LOG, "r") as f:
        logs = json.load(f)

    logs.append({
        "sender": sender,
        "receiver": receiver,
        "encrypted_message": base64.b64encode(encrypted_message).decode(),
        "nonce": base64.b64encode(nonce).decode(),
        "verified": verified,
        "timestamp": datetime.now().isoformat()
    })

    with open(RELAY_LOG, "w") as f:
        json.dump(logs, f, indent=4)

    return {"relayed": verified}


# =========================
# SIGN PDF (AES + ED25519)
# =========================
@app.post("/sign-pdf")
async def sign_pdf(file: UploadFile = File(...), user: str = Depends(get_current_user)):
    if SERVER_PRIVATE_KEY is None:
        raise HTTPException(500, "Server private key tidak ditemukan")

    pdf_bytes = await file.read()
    nonce, encrypted_pdf = encrypt_data(pdf_bytes)

    signature = SERVER_PRIVATE_KEY.sign(encrypted_pdf)

    return {
        "filename": file.filename,
        "encrypted_pdf": base64.b64encode(encrypted_pdf).decode(),
        "nonce": base64.b64encode(nonce).decode(),
        "signature": base64.b64encode(signature).decode()
    }


# =========================
# VERIFY PDF
# =========================
@app.post("/verify-pdf")
async def verify_pdf(
    username: str,
    encrypted_pdf: str,
    nonce: str,
    signature: str,
    user: str = Depends(get_current_user)
):
    with open(KEY_FILE, "r") as f:
        users = json.load(f)

    if username not in users:
        raise HTTPException(404, "User tidak ditemukan")

    public_key = serialization.load_pem_public_key(users[username].encode())

    encrypted_pdf_bytes = base64.b64decode(encrypted_pdf)
    nonce_bytes = base64.b64decode(nonce)

    try:
        public_key.verify(base64.b64decode(signature), encrypted_pdf_bytes)
        plaintext_pdf = decrypt_data(nonce_bytes, encrypted_pdf_bytes)
        return {"verified": True}
    except:
        return {"verified": False}


# =========================
# TOKEN
# =========================
@app.post("/token")
async def generate_token(username: str):
    token = create_access_token({"sub": username})
    return {"access_token": token, "token_type": "bearer"}
