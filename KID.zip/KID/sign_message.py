from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization
import base64

with open("fitri_private.pem", "rb") as f:
    fitri_private = serialization.load_pem_private_key(
        f.read(),
        password=None,
    )

message = input("Masukkan pesan yang ingin ditandatangani: ").encode()
signature = fitri_private.sign(message)
signature_b64 = base64.b64encode(signature).decode()

print("\n=== HASIL SIGNATURE ===")
print(signature_b64)
print("\nSignature siap dipakai untuk /verify")
