from fastapi import FastAPI, UploadFile, File, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, OAuth2PasswordBearer, APIKeyHeader
from datetime import datetime, timedelta
from cryptography.hazmat.primitives import serialization
import base64
import json
import jwt
import os


# SECURITY SCHEME 
oauth2_scheme = APIKeyHeader(name="Authorization")
bearer_scheme = HTTPBearer()

# SERVER PRIVATE KEY
SERVER_PRIVKEY_PATH = "punkhazard-keys/priv19.pem"
if os.path.exists(SERVER_PRIVKEY_PATH):
    with open(SERVER_PRIVKEY_PATH, "rb") as f:
        SERVER_PRIVATE_KEY = serialization.load_pem_private_key(f.read(), password=None)
else:
    SERVER_PRIVATE_KEY = None

# JWT CONFIG
JWT_SECRET = "SUPER_SECRET_CHANGE_THIS"
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_MINUTES = 60

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=JWT_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)

# VALIDASI TOKEN 
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
    print("===== DEBUG AUTH =====")
    print("Header Authorization yang diterima server:")
    print(credentials)

    token = credentials.credentials
    print("Token yang diambil:", token)

    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        print("Token decode berhasil:", data)
        return data["sub"]
    except Exception as e:
        print("Token decode ERROR:", e)
        raise HTTPException(status_code=401, detail="Token invalid / expired")

# FASTAPI INIT
app = FastAPI(
    title="Security Service",
    version="1.0.0",
    description="UAS KID"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# STORAGE
DATA_DIR = "data"
KEY_FILE = f"{DATA_DIR}/keys.json"
VERIFY_LOG = f"{DATA_DIR}/verify_log.json"
RELAY_LOG = f"{DATA_DIR}/relay_log.json"

os.makedirs(DATA_DIR, exist_ok=True)

for file in [KEY_FILE, VERIFY_LOG, RELAY_LOG]:
    if not os.path.exists(file):
        with open(file, "w") as f:
            f.write("[]" if "log" in file else "{}")

# ROOT
@app.get("/")
async def index():
    return {
        "message": "Server SecurityAPI aktif! Buka /docs untuk testing API.",
        "timestamp": datetime.now().isoformat()
    }

# UPLOAD PDF
@app.post("/upload-pdf")
async def upload_pdf(file: UploadFile = File(...)):
    fname = "uploaded_" + file.filename
    contents = await file.read()
    with open(fname, "wb") as f:
        f.write(contents)

    return {"message": "File uploaded!", "saved_as": fname}


# STORE PUBLIC KEY
@app.post("/store")
async def store_pubkey(username: str, key: UploadFile = File(...)):
    if not key.filename.endswith(".pem"):
        raise HTTPException(400, "File harus .pem")

    key_data = (await key.read()).decode("utf-8")

    with open(KEY_FILE, "r") as f:
        data = json.load(f)

    data[username] = key_data

    with open(KEY_FILE, "w") as f:
        json.dump(data, f, indent=4)

    return {"message": "Public key disimpan", "username": username}

# VERIFY SIGNATURE
@app.post("/verify")
async def verify_signature(username: str, message: str, signature: str):
    with open(KEY_FILE, "r") as f:
        data = json.load(f)

    if username not in data:
        return {"verified": False, "message": "Username tidak ditemukan"}

    public_key = serialization.load_pem_public_key(data[username].encode())
    signature_bytes = base64.b64decode(signature)

    verified = True
    try:
        public_key.verify(signature_bytes, message.encode())
    except Exception:
        verified = False

    with open(VERIFY_LOG, "r") as f:
        logs = json.load(f)

    logs.append({
        "username": username,
        "message": message,
        "verified": verified,
        "timestamp": datetime.now().isoformat()
    })

    with open(VERIFY_LOG, "w") as f:
        json.dump(logs, f, indent=4)

    return {"verified": verified}

# RELAY
@app.post("/relay")
async def relay_message(sender: str, receiver: str, message: str, signature: str):
    with open(KEY_FILE, "r") as f:
        data = json.load(f)
    if sender not in data:
        return {"relayed": False, "message": "Sender tidak ditemukan"}

    public_key = serialization.load_pem_public_key(data[sender].encode())
    signature_bytes = base64.b64decode(signature)

    verified = True
    try:
        public_key.verify(signature_bytes, message.encode())
    except:
        verified = False
    with open(RELAY_LOG, "r") as f:
        logs = json.load(f)

    logs.append({
        "sender": sender,
        "receiver": receiver,
        "message": message,
        "verified": verified,
        "timestamp": datetime.now().isoformat()
    })

    with open(RELAY_LOG, "w") as f:
        json.dump(logs, f, indent=4)

    return {"relayed": verified}

# SIGN PDF 
@app.post("/sign-pdf")
async def sign_pdf(file: UploadFile = File(...), current_user: str = Depends(get_current_user)):
    if SERVER_PRIVATE_KEY is None:
        raise HTTPException(500, "Server private key tidak ditemukan")

    pdf_bytes = await file.read()
    signature = SERVER_PRIVATE_KEY.sign(pdf_bytes)

    return {
        "filename": file.filename,
        "signature": base64.b64encode(signature).decode()
    }

# VERIFY PDF 
@app.post("/verify-pdf")
async def verify_pdf(username: str, file: UploadFile = File(...), signature: str = None, current_user: str = Depends(get_current_user)):
    if not signature:
        raise HTTPException(400, "Signature wajib diisi")

    with open(KEY_FILE, "r") as f:
        users = json.load(f)

    if username not in users:
        raise HTTPException(404, "User tidak ditemukan")

    public_key = serialization.load_pem_public_key(users[username].encode())
    pdf_bytes = await file.read()

    try:
        public_key.verify(base64.b64decode(signature), pdf_bytes)
        return {"verified": True}
    except:
        return {"verified": False}

# TOKEN ENDPOINT
@app.post("/token")
async def generate_token(username: str):
    token = create_access_token({"sub": username})
    return {"access_token": token, "token_type": "bearer"}